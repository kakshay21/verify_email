# verify_email

``verify_email`` can verify if the email exists or not by checking the domain name and pinging and verifying the handler.

## Features
TODO

## Compatibility
- It is written in Python 2.7.
- Not tested in python3.X.
- It should work on Linux, Mac and Windows.

## Documentation
TODO

## Installation
### From pypi.org
```
pip install verify_email
```
### From source code
```
virtualenv env 
source env/bin/activate
pip install -r requirements.txt
python setup.py develop
```

## Usage
see [usage.py](https://github.com/kakshay21/verify_email/blob/master/verify_email/usage.py)

## Contribute
- Issue Tracker: https://github.com/kakshay21/verify_email/issues
- Source Code: https://github.com/kakshay21/verify_email

## Support
If you are having issues, please let me know.
